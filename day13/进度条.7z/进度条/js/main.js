/*
 * @Description: This is a JS program !
 * @Author: 史志龙
 * @Github: https://github.com/szl-shalom/
 * @Date: 2019-10-17 16:43:51
 * @LastEditors: 史志龙
 * @LastEditTime: 2019-10-17 18:43:11
 */
require(["dom", "progress", "data"], function ($, P, data) {
    new P({
        data: data,
        wrap: $.get(".wrap"),
        // progress: $.get(".progress"),
        // slide: $.get(".slide"),
        // box: $.get(".box"),
    })
})