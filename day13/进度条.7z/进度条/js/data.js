/*
 * @Description: This is a JS program !
 * @Author: 史志龙
 * @Github: https://github.com/szl-shalom/
 * @Date: 2019-10-17 17:05:16
 * @LastEditors: 史志龙
 * @LastEditTime: 2019-10-17 18:40:25
 */
define(function () {
    var index = 1
    function random(n, m) {
        return Math.floor(Math.random() * (m - n + 1) + n)
    }

    return [{
        name: "乾坤大挪移" + index++,
        count: random(0, 800)
    }, {
        name: "乾坤大挪移" + index++,
        count: random(0, 800)
    }, {
        name: "乾坤大挪移" + index++,
        count: random(0, 800)
    }]
})