/*
 * @Description: This is a JS program !
 * @Author: 史志龙
 * @Github: https://github.com/szl-shalom/
 * @Date: 2019-10-17 16:34:57
 * @LastEditors: 史志龙
 * @LastEditTime: 2019-10-17 19:07:09
 */
define(["../velocity.min"], function (V) {
    class P {
        constructor(opt) {
            Object.assign(this, opt)
            this.render();
            this.bindEvent();

        }
        render() {
            console.log(this.data)
            this.wrap.innerHTML = this.data.map(function (item) {
                return `
               
                <div class="progress">
                    <div class="slide">${item.name}</div>
                    <div class="box">
                        <span></span>
                    </div>
                </div>
                `
            }).join("");

            [...this.wrap.children].forEach((item, index) => {
                V(item.querySelector(".slide"), {
                    width: this.data[index].count
                }, {
                    duration: 1000,
                })

                V(item.querySelector(".box"), {
                    left: this.data[index].count
                }, {
                    duration: 1000,
                    progress: (el, com) => {
                        item.querySelector("span").innerHTML = parseInt(com * this.data[index].count)
                    }
                })
            })


        }
        bindEvent() {
            var flag = false, el = null, left, parentLeft;
            this.wrap.onmousedown = e => {
                var tar = e.target;
                e.preventDefault()
                if (tar.className === "box") {
                    flag = true;
                    el = tar;
                    left = e.offsetX;
                    parentLeft = tar.parentNode.offsetLeft;
                }
            }
            document.onmousemove = e => {
                if (flag) {
                    var x = e.pageX - left - parentLeft;
                    if (x < 0) x = 0;
                    if (x > el.parentNode.offsetWidth - el.offsetWidth) x = el.parentNode.offsetWidth - el.offsetWidth
                    el.style.left = x + "px";
                    el.previousElementSibling.style.width = x + el.offsetWidth / 2 +"px"
                    el.firstElementChild.innerHTML = parseInt(x / 780 * 100) + "%"
                }
            }
            document.onmouseup = e => {
                flag = false
            }
        }
    }


    return P
})

